import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // The program's greeting.
        System.out.println("--Hello! I am a Calculator. What kind of calculation can I help you with?--");
        System.out.println("1: Basic Calculation (Addition, Subtraction, Multiplication, Division");
        System.out.println("2: Advanced Calculation (Power, Square Root");

        // The calculation choice.
        System.out.println("Enter your choice (1 or 2): ");
        int calculationType = scanner.nextInt();

        Calculator calculator = null;
        double result = 0;

        if (calculationType == 1) {

            //Basic calculation + options.
            calculator = new BasicCalculation();
            System.out.println("--Select your operation--");
            System.out.println("1: Addition/'+'");
            System.out.println("2: Subtraction/'-'");
            System.out.println("3: Multiplication/'*'");
            System.out.println("4: Division/'/'");

            // Inputting user choice.
            System.out.print("Enter your choice: ");
            int operation = scanner.nextInt();

            // Choosing which numbers to calculate.
            System.out.println("Enter first digit: ");
            double num1 = scanner.nextDouble();
            System.out.println("Enter second digit: ");
            double num2 = scanner.nextDouble();

            switch (operation) {
                case 1:
                    result = ((BasicCalculation) calculator).add(num1, num2);
                    break;
                case 2:
                    result = ((BasicCalculation) calculator).subtract(num1, num2);
                    break;
                case 3:
                    result = ((BasicCalculation) calculator).multiply(num1, num2);
                    break;
                case 4:
                    result = ((BasicCalculation) calculator).divide(num1, num2);
                    break;
                default:
                    System.out.println("**Invalid operation choice**");
                    return;
            }

        } else if (calculationType == 2) {

            // Advanced calculation + options.
            calculator = new AdvancedCalculation();
            System.out.println("--Select your operation--");
            System.out.println("1: Power (number ^ exponent)");
            System.out.println("2: Square Root");

            System.out.println("Enter your choice: ");
            int operation = scanner.nextInt();

            if (operation == 1) {
                System.out.println("Enter the base number: ");
                double baseNum = scanner.nextDouble();
                System.out.println("Enter the exponent: ");
                double exponent = scanner.nextDouble();
                result = ((AdvancedCalculation) calculator).power(baseNum, exponent);

            } else if (operation == 2){
                System.out.println("Enter the number to find the square root of: ");
                double num = scanner.nextDouble();
                result = ((AdvancedCalculation) calculator).squareRoot(num);
            } else {
                System.out.println("**Invalid operation choice**");
                return;
            }
        } else {
            System.out.println("**Invalid calculation type**");
            return;
        }

        if (calculator != null) {
            calculator.display(result);
        }

        scanner.close();
    }
}