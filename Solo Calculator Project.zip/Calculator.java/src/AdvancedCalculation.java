public class AdvancedCalculation extends Calculator {

    public double power(double base, double exponent) {return Math.pow(base, exponent);}
    public double squareRoot(double value) {
        if (value < 0) {
            System.out.println("**ERROR** Can't take the square root of a negative number.");
            return 0;
        }
        return Math.sqrt(value);
    }
    @Override
    public void display(double result) {
        System.out.println("Advanced Calculation Result: " + result);
    }
}
