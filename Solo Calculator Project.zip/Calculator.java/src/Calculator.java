public abstract class Calculator {
    public abstract void display(double result);
}
